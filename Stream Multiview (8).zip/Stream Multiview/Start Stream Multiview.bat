@echo off
title Stream Multiview
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 goto nonode

if exist "node_modules\electron\dist\electron.exe" goto run

echo.
echo  First launch: installing the app engine. This happens only once
echo  and takes about a minute...
echo.
call npm install --no-audit --no-fund
if errorlevel 1 goto installfail

:run
rem Make sure saved logins are stored encrypted (only changes anything the first time).
node harden.js >nul 2>nul
start "" "node_modules\electron\dist\electron.exe" .
exit /b

:nonode
echo.
echo  Stream Multiview needs Node.js (free) installed one time.
echo  Opening the download page now. Install the "LTS" version,
echo  then double-click this file again.
echo.
start https://nodejs.org/
pause
exit /b

:installfail
echo.
echo  The install didn't finish. Check your internet connection and
echo  double-click this file to try again.
echo.
pause
exit /b
